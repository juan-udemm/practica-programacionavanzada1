public abstract class Casillero
{
    public abstract void DefinirValor(int valor);
    public abstract void RealizarEfecto(Jugador jugador);
}