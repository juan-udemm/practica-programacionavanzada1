using System.Security.Cryptography.X509Certificates;

public class Jugador
{
    public string Nombre;
    public int Dinero;
    public int Energia;

    public Jugador(string nombre)
    {
        Nombre = nombre;
        Dinero = 100;
        Energia = 10;
    }
}