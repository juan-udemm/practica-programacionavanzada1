public class Tablero
{
    public Casillero[] casilleros;

    public Tablero(int maxcasilleros)
    {
        casilleros = new Casillero[maxcasilleros];
    }
}